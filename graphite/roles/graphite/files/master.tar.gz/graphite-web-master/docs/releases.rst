Release Notes
=============

.. toctree::
   :maxdepth: 1
   :glob:

   releases/0_10_0
   releases/0_9_13
   releases/0_9_12
   releases/0_9_11
   releases/0_9_10
   releases/0_9_9
   releases/0_9_8
   releases/0_9_7
   releases/0_9_6
   releases/0_9_5
   releases/0_9_4
   releases/0_9_3
   releases/0_9_2
