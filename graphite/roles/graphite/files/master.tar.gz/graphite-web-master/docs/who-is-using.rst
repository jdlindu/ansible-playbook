Who is using Graphite?
======================

Here are some organizations that use Graphite:

* `Brightcove <http://www.brightcove.com>`_ (see http://opensource.brightcove.com/project/Diamond/)
* `Canonical <http://www.canonical.com>`_
* `Datacratic <http://www.datacratic.com>`_
* `Douban <http://www.douban.com>`_
* `Dyn <http://dyn.com/>`_
* `Etsy <http://www.etsy.com/>`_ (see http://codeascraft.etsy.com/2010/12/08/track-every-release/)
* `GitHub <https://github.com>`_
* `Google <http://google-opensource.blogspot.com/2010/09/get-ready-to-rocksteady.html>`_ (opensource Rocksteady project)
* `ImmobilienScout24 <http://www.immobilienscout24.de/>`_
* `Instagram <http://instagram.com/>`_
* `ITV <http://www.itv.com/>`_
* `Media Temple <http://mediatemple.net/>`_
* `Orbitz <http://www.orbitz.com/>`_
* `Sears Holdings <http://www.sears.com/>`_
* `SocialTwist <http://www.socialtwist.com>`_
* `Uber <http://uber.com/>`_
* `Vimeo <http://www.vimeo.com>`_
* `Wikimedia Foundation <http://gdash.wikimedia.org/>`_

And many more
